﻿using System;
using System.Collections.Generic;
using Verse;

namespace AntiReality.Research
{
    public class WarpCostResearch : ResearchProjectDef
    {

    }
}
