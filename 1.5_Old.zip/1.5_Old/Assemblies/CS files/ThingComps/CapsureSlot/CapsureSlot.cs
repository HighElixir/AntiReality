﻿using Verse;

namespace AntiReality
{
    public class CapsureSlot : ThingDef
    {
        public string capsureName;
        public int fictionEnegyLimit;
        public float fictionEnegyFactor;
    }
}
